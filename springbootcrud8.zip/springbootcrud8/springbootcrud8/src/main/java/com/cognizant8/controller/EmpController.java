package com.cognizant8.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cognizant8.model.Employee;
import com.cognizant8.service.EmpService;

@RestController
public class EmpController {

	@Autowired
	EmpService empService;

	@PostMapping("/insert")
	public void insert(@RequestBody Employee employee) {

		empService.insert(employee);
	}
	
	@GetMapping("/retrive")
	public List<Employee> fetchData()
	{
		return empService.fetchData();
		
	}
	
	@DeleteMapping(value="/deleterecord/{id}")
	public void deleteRecord(@PathVariable Integer id)
	{
		
		empService.deleteRecord(id);
	}
	
	@PutMapping(value="/update/{id}")
	public void updateRecord(@PathVariable Integer id,@RequestBody Employee employee)
	{
		empService.updateRecord(id, employee);
	}

}
