package com.cognizant8.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant8.model.Employee;

public interface EmpRepository extends JpaRepository<Employee,Integer> {

	 
}
