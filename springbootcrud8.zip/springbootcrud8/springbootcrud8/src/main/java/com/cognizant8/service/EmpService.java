package com.cognizant8.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.cognizant8.dao.EmpDao;
import com.cognizant8.model.Employee;

@Service
public class EmpService {

	@Autowired
	EmpDao empDao;
	
	public void insert(Employee employee) {
		empDao.insert(employee);
	}
	
	public List<Employee> fetchData()
	{
		return empDao.fetchData();
		
	}
	
	public void deleteRecord(Integer id)
	{
		empDao.deleteRecord(id);
	}
	
	public void updateRecord(Integer id,Employee employee)
	{
		empDao.updateRecord(id, employee);
	}
}
