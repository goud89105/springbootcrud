package com.cognizant8.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant8.jpa.EmpRepository;
import com.cognizant8.model.Employee;

@Repository
public class EmpDao {

	@Autowired
	EmpRepository empRepository;

	public void insert(Employee employee) {
		empRepository.save(employee);
	}
	
	
	public List<Employee> fetchData()
	{
		return empRepository.findAll();
		
	}
	
	
	public void deleteRecord(Integer id)
	{
		empRepository.deleteById(id);
	}
	
	public void updateRecord(Integer id,Employee employee)
	{
		Employee employee1=empRepository.findById(id).orElseThrow();
		
		employee1.setEmpid(employee.getEmpid());
		employee1.setEmpname(employee.getEmpname());
		employee1.setEmpaddress(employee.getEmpaddress());
		
		empRepository.save(employee1);
	}
}
